# nobel-nomination-viz
Visualization of Nobel nominations with Javascript and D3.js

## Preview

![Preview](img/preview.jpg)

## Usage

1. Git Clone or download
2. open `src/nobel_visualzation.html` in live server with VSCode or Sublime Text or other editor 